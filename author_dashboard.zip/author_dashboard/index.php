<?php
require_once 'config.php';

// Chat form handling
$chatSuccess = '';
$chatError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['chat_form'])) {
    $chatName    = trim($_POST['chat_name'] ?? '');
    $chatEmail   = trim($_POST['chat_email'] ?? '');
    $chatMessage = trim($_POST['chat_message'] ?? '');

    if ($chatName === '' || $chatEmail === '' || $chatMessage === '') {
        $chatError = 'Please fill in all fields.';
    } else {
        // TODO: change this email to your own
        $to      = 'mdabsdq2004@gmail.com';
        $subject = 'New chat message from Author Dashboard';
        $body    = "Name: {$chatName}\nEmail: {$chatEmail}\n\nMessage:\n{$chatMessage}";
        $headers = "From: {$chatEmail}\r\nReply-To: {$chatEmail}\r\n";

        // On local XAMPP, mail() may not work until properly configured.
        if (@mail($to, $subject, $body, $headers)) {
            $chatSuccess = 'Your message has been sent. We will get back to you soon.';
            // Clear fields
            $chatName = $chatEmail = $chatMessage = '';
        } else {
            $chatError = 'Unable to send email. (On local XAMPP, mail() may need configuration.)';
        }
    }
}

$page = $_GET['page'] ?? 'dashboard';

$allowedPages = [
    'dashboard',
    'new_project',
    'messages',
    'contracts',
    'new_message',
    'edit_message',
    'new_contract',
    'edit_contract',
    'quotes',
    'payments'
];

if (!in_array($page, $allowedPages)) {
    $page = 'dashboard';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Author Dashboard</title>
    <style>
        /* Global layout & typography */
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    margin: 0;
    background: linear-gradient(135deg, #f5f7fb, #e4e8f2);
    color: #222;
}

header {
    background: #111827;
    color: #f9fafb;
    padding: 12px 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 8px rgba(0,0,0,0.15);
    position: sticky;
    top: 0;
    z-index: 10;
}

header .logo {
    font-weight: 700;
    font-size: 1.1rem;
    letter-spacing: 0.03em;
}

nav a {
    color: #e5e7eb;
    margin-left: 18px;
    text-decoration: none;
    font-size: 0.95rem;
    padding-bottom: 4px;
    border-bottom: 2px solid transparent;
    transition: color 0.2s ease, border-color 0.2s ease;
}

nav a:hover {
    color: #ffffff;
    border-color: #4f46e5;
}

nav a.active {
    color: #ffffff;
    border-color: #6366f1;
    font-weight: 600;
}

.container {
    max-width: 1080px;
    margin: 24px auto 40px;
    padding: 0 16px;
}

/* Page titles */
h2 {
    font-size: 1.4rem;
    margin-bottom: 16px;
    color: #111827;
}

/* Card-style wrapper (optional, for sections) */
.card {
    background: #ffffff;
    border-radius: 12px;
    padding: 18px 20px;
    box-shadow: 0 8px 20px rgba(15,23,42,0.08);
    margin-bottom: 20px;
}

/* Buttons */
.btn {
    display: inline-block;
    padding: 8px 14px;
    border-radius: 9999px;
    border: none;
    background: #4f46e5;
    color: #ffffff;
    text-decoration: none;
    cursor: pointer;
    font-size: 0.9rem;
    font-weight: 500;
    box-shadow: 0 4px 10px rgba(79,70,229,0.35);
    transition: transform 0.12s ease, box-shadow 0.12s ease, background 0.12s ease;
}

.btn:hover {
    background: #4338ca;
    transform: translateY(-1px);
    box-shadow: 0 6px 16px rgba(79,70,229,0.45);
}

.btn:active {
    transform: translateY(0);
    box-shadow: 0 2px 8px rgba(79,70,229,0.3);
}

.btn-secondary {
    background: #6b7280;
    box-shadow: none;
}

.btn-secondary:hover {
    background: #4b5563;
}

/* Forms */
form {
    background: #ffffff;
    padding: 18px 20px;
    border-radius: 12px;
    box-shadow: 0 8px 20px rgba(15,23,42,0.06);
}

form .form-group {
    margin-bottom: 12px;
}

form label {
    display: block;
    font-size: 0.9rem;
    margin-bottom: 4px;
    font-weight: 500;
    color: #374151;
}

input[type="text"],
input[type="number"],
input[type="date"],
select,
textarea {
    width: 100%;
    max-width: 480px;
    padding: 8px 10px;
    border-radius: 8px;
    border: 1px solid #d1d5db;
    font-size: 0.9rem;
    outline: none;
    transition: border-color 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
    background: #f9fafb;
}

textarea {
    min-height: 100px;
    resize: vertical;
}

input:focus,
select:focus,
textarea:focus {
    border-color: #4f46e5;
    box-shadow: 0 0 0 2px rgba(79,70,229,0.15);
    background: #ffffff;
}

/* Tables */
table {
    border-collapse: collapse;
    width: 100%;
    background: #ffffff;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 8px 20px rgba(15,23,42,0.06);
    margin-top: 10px;
}

table th, table td {
    padding: 10px 12px;
    font-size: 0.9rem;
}

table th {
    background: #f3f4f6;
    text-align: left;
    color: #4b5563;
    border-bottom: 1px solid #e5e7eb;
}

table tbody tr:nth-child(even) {
    background: #f9fafb;
}

table tbody tr:hover {
    background: #eef2ff;
}

/* Small info text */
.small-text {
    font-size: 0.8rem;
    color: #6b7280;
}

/* Filter row */
.filter-row {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 10px;
    font-size: 0.9rem;
}

.filter-row select {
    max-width: 200px;
}

/* Alerts / messages */
.alert {
    padding: 10px 12px;
    border-radius: 8px;
    margin-bottom: 12px;
    font-size: 0.9rem;
}

.alert-error {
    background: #fef2f2;
    color: #b91c1c;
    border: 1px solid #fecaca;
}

.alert-success {
    background: #ecfdf5;
    color: #15803d;
    border: 1px solid #bbf7d0;
}

/* Badges */
.badge {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 500;
}

.badge-unread {
    background: #fbbf24;
    color: #1f2937;
}

.badge-read {
    background: #22c55e;
    color: #064e3b;
}

/* Status colors (optional: use on project status text) */
.status-Draft { color: #6b7280; }
.status-Submitted { color: #0ea5e9; }
.status-In\ Progress { color: #6366f1; }
.status-Completed { color: #16a34a; }
.status-Cancelled { color: #b91c1c; }

/* Links inside content */
a {
    color: #4f46e5;
}

a:hover {
    color: #4338ca;
}

/* Responsive tweaks */
@media (max-width: 768px) {
    header {
        flex-direction: column;
        align-items: flex-start;
        gap: 8px;
    }

    nav a {
        margin-left: 0;
        margin-right: 14px;
    }

    table th, table td {
        font-size: 0.8rem;
        padding: 8px;
    }
}

/* Floating chat button (bottom right) */
.chat-fab {
    position: fixed;
    bottom: 24px;
    right: 24px;
    width: 52px;
    height: 52px;
    border-radius: 50%;
    background: #4f46e5;
    box-shadow: 0 8px 20px rgba(15,23,42,0.35);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #ffffff;
    text-decoration: none;
    font-size: 24px;
    cursor: pointer;
    z-index: 100;
    transition: transform 0.12s ease, box-shadow 0.12s ease, background 0.12s ease;
}

.chat-fab:hover {
    background: #4338ca;
    transform: translateY(-2px);
    box-shadow: 0 10px 24px rgba(15,23,42,0.45);
}

.chat-fab:active {
    transform: translateY(0);
    box-shadow: 0 4px 12px rgba(15,23,42,0.3);
}

/* Small tooltip style for chat button */
.chat-fab-tooltip {
    position: fixed;
    bottom: 84px;
    right: 24px;
    background: #111827;
    color: #e5e7eb;
    padding: 6px 10px;
    border-radius: 8px;
    font-size: 0.8rem;
    box-shadow: 0 6px 16px rgba(15,23,42,0.35);
    display: none;
    z-index: 99;
}

.chat-fab:hover + .chat-fab-tooltip {
    display: inline-block;
}

/* Chat popup box */
.chat-box {
    position: fixed;
    bottom: 84px;
    right: 24px;
    width: 320px;
    max-width: 90vw;
    background: #ffffff;
    border-radius: 12px;
    box-shadow: 0 10px 26px rgba(15,23,42,0.35);
    display: none; /* toggled with JS */
    flex-direction: column;
    z-index: 101;
    overflow: hidden;
}

.chat-box-header {
    background: #111827;
    color: #e5e7eb;
    padding: 10px 12px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 0.9rem;
}

.chat-box-header button {
    background: transparent;
    border: none;
    color: #9ca3af;
    font-size: 1.2rem;
    cursor: pointer;
}

.chat-box-header button:hover {
    color: #f9fafb;
}

.chat-box form {
    box-shadow: none;
    border-radius: 0;
    padding: 12px;
}

.chat-box .form-group {
    margin-bottom: 8px;
}

.chat-box input[type="text"],
.chat-box input[type="email"],
.chat-box textarea {
    max-width: 100%;
    font-size: 0.85rem;
}

.chat-box textarea {
    min-height: 80px;
}

.chat-box-footer {
    display: flex;
    justify-content: flex-end;
    margin-top: 4px;
}

.chat-box .btn {
    padding: 6px 12px;
    font-size: 0.8rem;
    box-shadow: none;
}

.chat-box .alert {
    margin-bottom: 8px;
    font-size: 0.8rem;
}

    </style>
</head>
<body>
<header>
    <div><strong>Author Dashboard</strong></div>
    <nav>
    <a href="index.php?page=dashboard" class="<?php echo $page === 'dashboard' ? 'active' : ''; ?>">Projects</a>
    <a href="index.php?page=new_project" class="<?php echo $page === 'new_project' ? 'active' : ''; ?>">New Project</a>
    <a href="index.php?page=messages" class="<?php echo $page === 'messages' ? 'active' : ''; ?>">Messages</a>
    <a href="index.php?page=contracts" class="<?php echo $page === 'contracts' ? 'active' : ''; ?>">Contracts</a>
    <a href="index.php?page=quotes" class="<?php echo $page === 'quotes' ? 'active' : ''; ?>">Quotes</a>
    <a href="index.php?page=payments" class="<?php echo $page === 'payments' ? 'active' : ''; ?>">Payments</a>
</nav>

</header>
<div class="container">
    <?php include __DIR__ . '/pages/' . $page . '.php'; ?>
</div>

<!-- Floating chat button (opens popup instead of navigating) -->
<a href="javascript:void(0)" class="chat-fab" title="Contact support" onclick="toggleChatBox()">
    &#128172; <!-- speech bubble icon -->
</a>
<div class="chat-fab-tooltip">Contact us</div>

<!-- Chat popup box -->
<div id="chatBox" class="chat-box">
    <div class="chat-box-header">
        <span>Contact support</span>
        <button type="button" onclick="toggleChatBox()">&times;</button>
    </div>
    <form method="post">
        <input type="hidden" name="chat_form" value="1">
        <?php if ($chatError): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($chatError); ?></div>
        <?php endif; ?>
        <?php if ($chatSuccess): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($chatSuccess); ?></div>
        <?php endif; ?>

        <div class="form-group">
            <label for="chat_name">Your name *</label>
            <input type="text" id="chat_name" name="chat_name"
                   value="<?php echo htmlspecialchars($chatName ?? ''); ?>">
        </div>

        <div class="form-group">
            <label for="chat_email">Your email *</label>
            <input type="text" id="chat_email" name="chat_email"
                   value="<?php echo htmlspecialchars($chatEmail ?? ''); ?>">
        </div>

        <div class="form-group">
            <label for="chat_message">Message *</label>
            <textarea id="chat_message" name="chat_message"><?php echo htmlspecialchars($chatMessage ?? ''); ?></textarea>
        </div>

        <div class="chat-box-footer">
            <button type="submit" class="btn">Send</button>
        </div>
    </form>
</div>

<script>
function toggleChatBox() {
    var box = document.getElementById('chatBox');
    if (!box) return;
    if (box.style.display === 'flex') {
        box.style.display = 'none';
    } else {
        box.style.display = 'flex';
    }
}

// If there was a chat error or success, keep the box open after submit
<?php if ($chatError || $chatSuccess): ?>
document.addEventListener('DOMContentLoaded', function () {
    var box = document.getElementById('chatBox');
    if (box) {
        box.style.display = 'flex';
    }
});
<?php endif; ?>
</script>

</body>
</html>
