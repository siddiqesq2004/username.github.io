<?php
// pages/quotes.php

// Fetch projects for dropdown
$stmtProjects = $pdo->query("SELECT id, title FROM projects ORDER BY created_at DESC");
$projects = $stmtProjects->fetchAll(PDO::FETCH_ASSOC);

$errors = [];
$success = '';

$project_id = '';
$title = '';
$description = '';
$amount = '';
$currency = 'USD';
$status = 'Draft';

$statuses = ['Draft','Sent','Accepted','Rejected'];

// Handle form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $project_id  = (int)($_POST['project_id'] ?? 0);
    $title       = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $amount      = trim($_POST['amount'] ?? '');
    $currency    = trim($_POST['currency'] ?? 'USD');
    $status      = $_POST['status'] ?? 'Draft';

    if ($project_id <= 0) {
        $errors[] = 'Please select a project.';
    }
    if ($title === '') {
        $errors[] = 'Title is required.';
    }
    if ($amount === '' || !is_numeric($amount)) {
        $errors[] = 'Amount must be a number.';
    }
    if ($currency === '') {
        $errors[] = 'Currency is required.';
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("
            INSERT INTO quotes (project_id, title, description, amount, currency, status)
            VALUES (:project_id, :title, :description, :amount, :currency, :status)
        ");
        $stmt->execute([
            ':project_id'  => $project_id,
            ':title'       => $title,
            ':description' => $description,
            ':amount'      => $amount,
            ':currency'    => $currency,
            ':status'      => $status
        ]);

        // Optional: create system message notifying about new quote
        $msg = $pdo->prepare("
            INSERT INTO messages (project_id, sender, body, is_read)
            VALUES (:project_id, 'System', :body, 0)
        ");
        $bodyText = 'New quote "' . $title . '" created with amount '
            . $currency . ' ' . number_format((float)$amount, 2)
            . ' and status "' . $status . '".';
        $msg->execute([
            ':project_id' => $project_id,
            ':body'       => $bodyText
        ]);

        $success = 'Quote created successfully.';
        $project_id = '';
        $title = '';
        $description = '';
        $amount = '';
        $currency = 'USD';
        $status = 'Draft';
    }
}

// Fetch existing quotes to display
$stmtQuotes = $pdo->query("
    SELECT q.*, p.title AS project_title
    FROM quotes q
    LEFT JOIN projects p ON q.project_id = p.id
    ORDER BY q.created_at DESC
");
$quotes = $stmtQuotes->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Quotes / Proposals</h2>

<div class="card">
    <h3 style="font-size:1rem; margin-bottom:10px;">Create a new quote</h3>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <ul>
                <?php foreach ($errors as $e): ?>
                    <li><?php echo htmlspecialchars($e); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success">
            <?php echo htmlspecialchars($success); ?>
        </div>
    <?php endif; ?>

    <form method="post">
        <div class="form-group">
            <label for="project_id">Project *</label>
            <select name="project_id" id="project_id">
                <option value="">-- Select a project --</option>
                <?php foreach ($projects as $p): ?>
                    <option value="<?php echo $p['id']; ?>"
                        <?php echo ($project_id == $p['id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($p['title']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="title">Quote title *</label>
            <input type="text" id="title" name="title"
                   value="<?php echo htmlspecialchars($title); ?>">
        </div>

        <div class="form-group">
            <label for="description">Description / details</label>
            <textarea id="description" name="description"><?php echo htmlspecialchars($description); ?></textarea>
        </div>

        <div class="form-group">
            <label for="amount">Amount *</label>
            <input type="number" step="0.01" id="amount" name="amount"
                   value="<?php echo htmlspecialchars($amount); ?>">
        </div>

        <div class="form-group">
            <label for="currency">Currency *</label>
            <input type="text" id="currency" name="currency"
                   value="<?php echo htmlspecialchars($currency); ?>">
        </div>

        <div class="form-group">
            <label for="status">Status *</label>
            <select id="status" name="status">
                <?php foreach ($statuses as $s): ?>
                    <option value="<?php echo $s; ?>"
                        <?php echo ($status === $s) ? 'selected' : ''; ?>>
                        <?php echo $s; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <button type="submit" class="btn">Save Quote</button>
    </form>
</div>

<div class="card">
    <h3 style="font-size:1rem; margin-bottom:10px;">Existing quotes</h3>

    <?php if (empty($quotes)): ?>
        <p class="small-text">No quotes created yet.</p>
    <?php else: ?>
        <table>
            <thead>
            <tr>
                <th>Project</th>
                <th>Title</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Created</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($quotes as $q): ?>
                <tr>
                    <td><?php echo htmlspecialchars($q['project_title'] ?? 'Unknown'); ?></td>
                    <td><?php echo htmlspecialchars($q['title']); ?></td>
                    <td><?php echo htmlspecialchars($q['currency']) . ' ' . number_format($q['amount'], 2); ?></td>
                    <td><?php echo htmlspecialchars($q['status']); ?></td>
                    <td><?php echo $q['created_at']; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
