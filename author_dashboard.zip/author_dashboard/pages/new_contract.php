<?php
// pages/new_contract.php

// Fetch projects for dropdown
$stmtProjects = $pdo->query("SELECT id, title FROM projects ORDER BY created_at DESC");
$projects = $stmtProjects->fetchAll(PDO::FETCH_ASSOC);

$errors = [];
$success = '';

$project_id = '';
$rate = '';
$currency = 'USD';
$status = 'Pending';
$signed_on = '';
$effective_from = '';
$ends_on = '';

$statuses = ['Pending', 'Active', 'Completed', 'Cancelled'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $project_id = (int)($_POST['project_id'] ?? 0);
    $rate = trim($_POST['rate'] ?? '');
    $currency = trim($_POST['currency'] ?? 'USD');
    $status = $_POST['status'] ?? 'Pending';
    $signed_on = $_POST['signed_on'] ?: null;
    $effective_from = $_POST['effective_from'] ?: null;
    $ends_on = $_POST['ends_on'] ?: null;

    if ($project_id <= 0) {
        $errors[] = 'Please select a project.';
    }
    if ($rate === '' || !is_numeric($rate)) {
        $errors[] = 'Rate must be a number.';
    }
    if ($currency === '') {
        $errors[] = 'Currency is required.';
    }

    if (empty($errors)) {
        // 1) Insert the contract
        $stmt = $pdo->prepare("
            INSERT INTO contracts (project_id, rate, currency, status, signed_on, effective_from, ends_on)
            VALUES (:project_id, :rate, :currency, :status, :signed_on, :effective_from, :ends_on)
        ");
        $stmt->execute([
            ':project_id' => $project_id,
            ':rate' => $rate,
            ':currency' => $currency,
            ':status' => $status,
            ':signed_on' => $signed_on,
            ':effective_from' => $effective_from,
            ':ends_on' => $ends_on
        ]);

        // 2) AUTOMATION: create a system message for this contract
        $msgStmt = $pdo->prepare("
            INSERT INTO messages (project_id, sender, body, is_read)
            VALUES (:project_id, 'System', :body, 0)
        ");

        $bodyText = 'A new contract has been created for this project with rate '
            . $currency . ' ' . number_format((float)$rate, 2)
            . ' and status "' . $status . '".';

        $msgStmt->execute([
            ':project_id' => $project_id,
            ':body' => $bodyText
        ]);

        // 3) Show success and reset form
        $success = 'Contract created successfully (and a system message was added).';
        $project_id = '';
        $rate = '';
        $currency = 'USD';
        $status = 'Pending';
        $signed_on = '';
        $effective_from = '';
        $ends_on = '';
    }
}
?>

<h2>New Contract</h2>

<?php if (!empty($errors)): ?>
    <div class="alert alert-error">
        <ul>
            <?php foreach ($errors as $e): ?>
                <li><?php echo htmlspecialchars($e); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="alert alert-success">
        <?php echo htmlspecialchars($success); ?>
        [<a href="index.php?page=contracts">Back to Contracts</a>]
    </div>
<?php endif; ?>

<form method="post">
    <div class="form-group">
        <label for="project_id">Project *</label>
        <select name="project_id" id="project_id">
            <option value="">-- Select a project --</option>
            <?php foreach ($projects as $p): ?>
                <option value="<?php echo $p['id']; ?>"
                    <?php echo ($project_id == $p['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($p['title']); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label for="rate">Rate *</label>
        <input type="number" step="0.01" id="rate" name="rate"
               value="<?php echo htmlspecialchars($rate); ?>">
    </div>

    <div class="form-group">
        <label for="currency">Currency *</label>
        <input type="text" id="currency" name="currency"
               value="<?php echo htmlspecialchars($currency); ?>">
    </div>

    <div class="form-group">
        <label for="status">Status *</label>
        <select name="status" id="status">
            <?php foreach ($statuses as $s): ?>
                <option value="<?php echo $s; ?>"
                    <?php echo ($status === $s) ? 'selected' : ''; ?>>
                    <?php echo $s; ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label for="signed_on">Signed On</label>
        <input type="date" id="signed_on" name="signed_on"
               value="<?php echo htmlspecialchars($signed_on); ?>">
    </div>

    <div class="form-group">
        <label for="effective_from">Effective From</label>
        <input type="date" id="effective_from" name="effective_from"
               value="<?php echo htmlspecialchars($effective_from); ?>">
    </div>

    <div class="form-group">
        <label for="ends_on">Ends On</label>
        <input type="date" id="ends_on" name="ends_on"
               value="<?php echo htmlspecialchars($ends_on); ?>">
    </div>

    <button type="submit" class="btn">Save Contract</button>
    <a href="index.php?page=contracts" class="btn btn-secondary">Cancel</a>
</form>
