<?php
// pages/messages.php

// Handle mark-as-read / mark-as-unread
if (isset($_GET['id']) && isset($_GET['set_read'])) {
    $id = (int)$_GET['id'];
    $setRead = ($_GET['set_read'] === '1') ? 1 : 0;

    if ($id > 0) {
        $stmtUpdate = $pdo->prepare("UPDATE messages SET is_read = :is_read WHERE id = :id");
        $stmtUpdate->execute([
            ':is_read' => $setRead,
            ':id'      => $id
        ]);
    }

    if (isset($_GET['id']) && isset($_GET['set_read'])) {
    $id = (int)$_GET['id'];
    $setRead = ($_GET['set_read'] === '1') ? 1 : 0;

    if ($id > 0) {
        $stmtUpdate = $pdo->prepare("UPDATE messages SET is_read = :is_read WHERE id = :id");
        $stmtUpdate->execute([
            ':is_read' => $setRead,
            ':id'      => $id
        ]);
    }

    // Redirect using JavaScript instead of PHP header()
    echo "<script>window.location.href = 'index.php?page=messages';</script>";
    exit;
}

}

// Fetch messages + project title
$stmt = $pdo->query("
    SELECT m.*, p.title AS project_title
    FROM messages m
    LEFT JOIN projects p ON m.project_id = p.id
    ORDER BY m.created_at DESC
");
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Messages & Notifications</h2>

<div class="card">

    <div style="margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center;">
        <span class="small-text">System and project messages. Click actions on the right to mark as read/unread.</span>
        <!-- If you have new_message.php, you can show this button -->
        <!-- <a href="index.php?page=new_message" class="btn">+ New Message</a> -->
    </div>

    <?php if (empty($messages)): ?>
        <p>No messages yet.</p>
    <?php else: ?>
        <table>
            <thead>
            <tr>
                <th>Project</th>
                <th>From</th>
                <th>Message</th>
                <th>Status</th>
                <th>Received At</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($messages as $msg): ?>
                <tr>
                    <td><?php echo htmlspecialchars($msg['project_title'] ?? 'General'); ?></td>
                    <td><?php echo htmlspecialchars($msg['sender']); ?></td>
                    <td><?php echo nl2br(htmlspecialchars($msg['body'])); ?></td>
                    <td>
                        <?php if ($msg['is_read']): ?>
                            <span class="badge badge-read">Read</span>
                        <?php else: ?>
                            <span class="badge badge-unread">Unread</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo $msg['created_at']; ?></td>
                    <td>
                        <?php if ($msg['is_read']): ?>
                            <a href="index.php?page=messages&id=<?php echo $msg['id']; ?>&set_read=0"
                               class="small-text">
                                Mark as unread
                            </a>
                        <?php else: ?>
                            <a href="index.php?page=messages&id=<?php echo $msg['id']; ?>&set_read=1"
                               class="small-text">
                                Mark as read
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <p style="margin-top: 10px;" class="small-text">
        (Later you can add a full messaging UI with threads, reply box, etc.)
    </p>
</div>
