<?php
// pages/new_project.php

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $genre = trim($_POST['genre'] ?? '');
    $word_count = (int)($_POST['word_count'] ?? 0);
    $deadline = $_POST['deadline'] ?? null;
    $status = $_POST['status'] ?? 'Draft';

    // Basic validation
    if ($title === '') {
        $errors[] = 'Title is required.';
    }
    if ($word_count < 0) {
        $errors[] = 'Word count must be zero or positive.';
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("
            INSERT INTO projects (title, description, genre, word_count, deadline, status)
            VALUES (:title, :description, :genre, :word_count, :deadline, :status)
        ");
        $stmt->execute([
            ':title' => $title,
            ':description' => $description,
            ':genre' => $genre,
            ':word_count' => $word_count ?: null,
            ':deadline' => $deadline ?: null,
            ':status' => $status
        ]);
// Get the ID of the new project
$projectId = $pdo->lastInsertId();

// Automatically create a system message for the new project
$msgStmt = $pdo->prepare("
    INSERT INTO messages (project_id, sender, body, is_read)
    VALUES (:project_id, :sender, :body, 0)
");
$msgStmt->execute([
    ':project_id' => $projectId,
    ':sender' => 'System',
    ':body' => 'Your project "' . $title . '" has been created.'
]);

        // Simple success message + clear form
        $success = 'Project created successfully!';
        $title = $description = $genre = '';
        $word_count = 0;
        $deadline = '';
        $status = 'Draft';
    }
}

// For status dropdown
$statuses = ['Draft', 'Submitted', 'In Progress', 'Completed', 'Cancelled'];

?>

<h2>Create New Project</h2>

<?php if (!empty($errors)): ?>
    <div style="color: red; margin-bottom: 10px;">
        <ul>
            <?php foreach ($errors as $e): ?>
                <li><?php echo htmlspecialchars($e); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<?php if ($success): ?>
    <div style="color: green; margin-bottom: 10px;">
        <?php echo htmlspecialchars($success); ?>
        [<a href="index.php?page=dashboard">Go to Projects</a>]
    </div>
<?php endif; ?>

<form method="post">
    <div style="margin-bottom: 8px;">
        <label>Title *</label><br>
        <input type="text" name="title" style="width: 300px;"
               value="<?php echo htmlspecialchars($title ?? ''); ?>">
    </div>

    <div style="margin-bottom: 8px;">
        <label>Description</label><br>
        <textarea name="description" rows="4" cols="50"><?php echo htmlspecialchars($description ?? ''); ?></textarea>
    </div>

    <div style="margin-bottom: 8px;">
        <label>Genre</label><br>
        <input type="text" name="genre" style="width: 200px;"
               value="<?php echo htmlspecialchars($genre ?? ''); ?>">
    </div>

    <div style="margin-bottom: 8px;">
        <label>Word Count (estimated)</label><br>
        <input type="number" name="word_count" min="0"
               value="<?php echo (int)($word_count ?? 0); ?>">
    </div>

    <div style="margin-bottom: 8px;">
        <label>Deadline</label><br>
        <input type="date" name="deadline" value="<?php echo htmlspecialchars($deadline ?? ''); ?>">
    </div>

    <div style="margin-bottom: 8px;">
        <label>Status</label><br>
        <select name="status">
            <?php foreach ($statuses as $s): ?>
                <option value="<?php echo $s; ?>" <?php echo (($status ?? '') === $s) ? 'selected' : ''; ?>>
                    <?php echo $s; ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <button type="submit" class="btn">Create Project</button>
    <a href="index.php?page=dashboard" class="btn btn-secondary">Cancel</a>
</form>
