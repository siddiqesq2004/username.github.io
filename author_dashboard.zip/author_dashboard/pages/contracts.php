<?php
// pages/contracts.php

$stmt = $pdo->query("
    SELECT c.*, p.title AS project_title
    FROM contracts c
    LEFT JOIN projects p ON c.project_id = p.id
    ORDER BY c.created_at DESC
");
$contracts = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Contract Summary</h2>

<div class="card">
    <div style="margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center;">
        <span class="small-text">Manage contracts linked to your projects.</span>
        <a href="index.php?page=new_contract" class="btn">+ New Contract</a>
    </div>

    <?php if (empty($contracts)): ?>
        <p>You have no contracts yet. <a href="index.php?page=new_contract">Create one</a>.</p>
    <?php else: ?>
        <table>
            <thead>
            <tr>
                <th>Project</th>
                <th>Rate</th>
                <th>Status</th>
                <th>Signed On</th>
                <th>Effective</th>
                <th>Ends</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($contracts as $c): ?>
                <tr>
                    <td><?php echo htmlspecialchars($c['project_title'] ?? 'Unknown'); ?></td>
                    <td><?php echo htmlspecialchars($c['currency']) . ' ' . number_format($c['rate'], 2); ?></td>
                    <td><?php echo $c['status']; ?></td>
                    <td><?php echo $c['signed_on']; ?></td>
                    <td><?php echo $c['effective_from']; ?></td>
                    <td><?php echo $c['ends_on']; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <p style="margin-top: 10px;" class="small-text">
        (Later you can add contract upload, e-sign, PDF links, etc.)
    </p>
</div>
