<?php
// pages/dashboard.php

$statusFilter = $_GET['status'] ?? '';

$query = "SELECT * FROM projects";
$params = [];

if ($statusFilter && $statusFilter !== 'all') {
    $query .= " WHERE status = :status";
    $params[':status'] = $statusFilter;
}

$query .= " ORDER BY created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$projects = $stmt->fetchAll(PDO::FETCH_ASSOC);

// For dropdown
$statuses = ['all', 'Draft', 'Submitted', 'In Progress', 'Completed', 'Cancelled'];
?>

<h2>My Projects</h2>

<div class="card">

    <!-- Create Button -->
    <div style="margin-bottom: 15px;">
        <a href="index.php?page=new_project" class="btn">+ Create New Project</a>
    </div>

    <!-- Filter Row -->
    <form method="get" class="filter-row">
        <input type="hidden" name="page" value="dashboard">
        <label for="status">Filter by status:</label>
        <select name="status" id="status" onchange="this.form.submit()">
            <?php foreach ($statuses as $status): ?>
                <option value="<?php echo $status; ?>"
                    <?php echo ($status == $statusFilter || ($statusFilter === '' && $status === 'all')) ? 'selected' : ''; ?>>
                    <?php echo $status; ?>
                </option>
            <?php endforeach; ?>
        </select>
    </form>

    <!-- Projects Table -->
    <?php if (empty($projects)): ?>
        <p>You have no projects yet. <a href="index.php?page=new_project">Create your first project</a>.</p>
    <?php else: ?>
        <table>
            <thead>
            <tr>
                <th>Title</th>
                <th>Genre</th>
                <th>Word Count</th>
                <th>Deadline</th>
                <th>Status</th>
                <th>Created At</th>
            </tr>
            </thead>

            <tbody>
            <?php foreach ($projects as $project): ?>
                <tr>
                    <td><?php echo htmlspecialchars($project['title']); ?></td>
                    <td><?php echo htmlspecialchars($project['genre']); ?></td>
                    <td><?php echo (int)$project['word_count']; ?></td>
                    <td><?php echo $project['deadline']; ?></td>
                    <td class="status-<?php echo str_replace(' ', '\\ ', $project['status']); ?>">
                        <?php echo $project['status']; ?>
                    </td>
                    <td><?php echo $project['created_at']; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>

        </table>
    <?php endif; ?>

</div>

