<?php
// pages/payments.php

// Fetch projects for dropdown
$stmtProjects = $pdo->query("SELECT id, title FROM projects ORDER BY created_at DESC");
$projects = $stmtProjects->fetchAll(PDO::FETCH_ASSOC);

$errors = [];
$success = '';

// Form state
$project_id = '';
$amount = '';
$currency = 'USD';
$method = '';
$upi_id = '';
$card_number = '';
$card_expiry = '';
$status = 'Paid'; // default for confirmation
$paid_at = date('Y-m-d\TH:i'); // HTML datetime-local format

$statuses = ['Pending','Paid','Failed'];
$methods  = ['UPI', 'Card']; // allowed payment methods

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $project_id  = (int)($_POST['project_id'] ?? 0);
    $amount      = trim($_POST['amount'] ?? '');
    $currency    = trim($_POST['currency'] ?? 'USD');
    $method      = trim($_POST['method'] ?? '');
    $upi_id      = trim($_POST['upi_id'] ?? '');
    $card_number = trim($_POST['card_number'] ?? '');
    $card_expiry = trim($_POST['card_expiry'] ?? '');
    $status      = $_POST['status'] ?? 'Paid';
    $paid_at     = $_POST['paid_at'] ?? '';

    if ($project_id <= 0) {
        $errors[] = 'Please select a project.';
    }
    if ($amount === '' || !is_numeric($amount)) {
        $errors[] = 'Amount must be a number.';
    }
    if (!in_array($currency, ['USD', 'INR'], true)) {
        $errors[] = 'Invalid currency selected.';
    }
    if ($method === '' || !in_array($method, $methods, true)) {
        $errors[] = 'Please select a valid payment method.';
    }

    // Validate based on method
    $transaction_ref = '';
    if ($method === 'UPI') {
        if ($upi_id === '') {
            $errors[] = 'UPI ID is required.';
        } else {
            $transaction_ref = 'UPI: ' . $upi_id;
        }
    } elseif ($method === 'Card') {
        if ($card_number === '' || $card_expiry === '') {
            $errors[] = 'Card number and expiry date are required.';
        } else {
            // Store masked-ish card info (for safety, do NOT store full sensitive data in real systems)
            $last4 = substr(preg_replace('/\D/', '', $card_number), -4);
            $transaction_ref = 'Card **** **** **** ' . $last4 . ' (Exp: ' . $card_expiry . ')';
        }
    }

    if ($paid_at === '') {
        $errors[] = 'Paid at datetime is required.';
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("
            INSERT INTO payments (project_id, amount, currency, method, transaction_ref, status, paid_at)
            VALUES (:project_id, :amount, :currency, :method, :transaction_ref, :status, :paid_at)
        ");
        $stmt->execute([
            ':project_id'      => $project_id,
            ':amount'          => $amount,
            ':currency'        => $currency,
            ':method'          => $method,
            ':transaction_ref' => $transaction_ref,
            ':status'          => $status,
            ':paid_at'         => $paid_at
        ]);

        // Optional: system message for payment
        $msg = $pdo->prepare("
            INSERT INTO messages (project_id, sender, body, is_read)
            VALUES (:project_id, 'System', :body, 0)
        ");
        $bodyText = 'Payment recorded: ' . $currency . ' ' . number_format((float)$amount, 2)
            . ' via ' . $method . ' (status: ' . $status . ').';
        $msg->execute([
            ':project_id' => $project_id,
            ':body'       => $bodyText
        ]);

        $success = 'Payment confirmation recorded successfully.';
        // reset form
        $project_id = '';
        $amount = '';
        $currency = 'USD';
        $method = '';
        $upi_id = '';
        $card_number = '';
        $card_expiry = '';
        $status = 'Paid';
        $paid_at = date('Y-m-d\TH:i');
    }
}

// Fetch payment history
$stmtPayments = $pdo->query("
    SELECT pay.*, p.title AS project_title
    FROM payments pay
    LEFT JOIN projects p ON pay.project_id = p.id
    ORDER BY pay.created_at DESC
");
$payments = $stmtPayments->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Payment Confirmation</h2>

<div class="card">
    <h3 style="font-size:1rem; margin-bottom:10px;">Record a payment</h3>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <ul>
                <?php foreach ($errors as $e): ?>
                    <li><?php echo htmlspecialchars($e); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success">
            <?php echo htmlspecialchars($success); ?>
        </div>
    <?php endif; ?>

    <form method="post">
        <div class="form-group">
            <label for="project_id">Project *</label>
            <select name="project_id" id="project_id">
                <option value="">-- Select a project --</option>
                <?php foreach ($projects as $p): ?>
                    <option value="<?php echo $p['id']; ?>"
                        <?php echo ($project_id == $p['id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($p['title']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="amount">Amount *</label>
            <input type="number" step="0.01" id="amount" name="amount"
                   value="<?php echo htmlspecialchars($amount); ?>">
        </div>

        <div class="form-group">
            <label for="currency">Currency *</label>
            <select id="currency" name="currency">
                <option value="USD" <?php echo $currency === 'USD' ? 'selected' : ''; ?>>USD</option>
                <option value="INR" <?php echo $currency === 'INR' ? 'selected' : ''; ?>>INR</option>
            </select>
        </div>

        <div class="form-group">
            <label for="method">Payment method *</label>
            <select id="method" name="method">
                <option value="">-- Select method --</option>
                <?php foreach ($methods as $m): ?>
                    <option value="<?php echo $m; ?>"
                        <?php echo ($method === $m) ? 'selected' : ''; ?>>
                        <?php echo $m; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- UPI field -->
        <div class="form-group" id="upi_group" style="display:none;">
            <label for="upi_id">UPI ID *</label>
            <input type="text" id="upi_id" name="upi_id"
                   placeholder="yourname@upi"
                   value="<?php echo htmlspecialchars($upi_id); ?>">
        </div>

        <!-- Card fields -->
        <div id="card_group" style="display:none;">
            <div class="form-group">
                <label for="card_number">Card number *</label>
                <input type="text" id="card_number" name="card_number"
                       placeholder="XXXX-XXXX-XXXX-1234"
                       value="<?php echo htmlspecialchars($card_number); ?>">
            </div>
            <div class="form-group">
                <label for="card_expiry">Expiry date *</label>
                <input type="month" id="card_expiry" name="card_expiry"
                       value="<?php echo htmlspecialchars($card_expiry); ?>">
            </div>
        </div>

        <div class="form-group">
            <label for="status">Status *</label>
            <select id="status" name="status">
                <?php foreach ($statuses as $s): ?>
                    <option value="<?php echo $s; ?>"
                        <?php echo ($status === $s) ? 'selected' : ''; ?>>
                        <?php echo $s; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="paid_at">Paid at *</label>
            <input type="datetime-local" id="paid_at" name="paid_at"
                   value="<?php echo htmlspecialchars($paid_at); ?>">
        </div>

        <button type="submit" class="btn">Save Payment</button>
    </form>
</div>

<div class="card">
    <h3 style="font-size:1rem; margin-bottom:10px;">Payment history</h3>

    <?php if (empty($payments)): ?>
        <p class="small-text">No payments recorded yet.</p>
    <?php else: ?>
        <table>
            <thead>
            <tr>
                <th>Project</th>
                <th>Amount</th>
                <th>Method</th>
                <th>Details</th>
                <th>Status</th>
                <th>Paid at</th>
                <th>Created</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($payments as $pay): ?>
                <tr>
                    <td><?php echo htmlspecialchars($pay['project_title'] ?? 'Unknown'); ?></td>
                    <td><?php echo htmlspecialchars($pay['currency']) . ' ' . number_format($pay['amount'], 2); ?></td>
                    <td><?php echo htmlspecialchars($pay['method']); ?></td>
                    <td><?php echo htmlspecialchars($pay['transaction_ref']); ?></td>
                    <td><?php echo htmlspecialchars($pay['status']); ?></td>
                    <td><?php echo $pay['paid_at']; ?></td>
                    <td><?php echo $pay['created_at']; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var methodSelect = document.getElementById('method');
    var upiGroup     = document.getElementById('upi_group');
    var cardGroup    = document.getElementById('card_group');

    function updatePaymentFields() {
        var val = methodSelect.value;
        if (val === 'UPI') {
            upiGroup.style.display  = 'block';
            cardGroup.style.display = 'none';
        } else if (val === 'Card') {
            upiGroup.style.display  = 'none';
            cardGroup.style.display = 'block';
        } else {
            upiGroup.style.display  = 'none';
            cardGroup.style.display = 'none';
        }
    }

    if (methodSelect) {
        methodSelect.addEventListener('change', updatePaymentFields);
        updatePaymentFields(); // set initial on load
    }
});
</script>
