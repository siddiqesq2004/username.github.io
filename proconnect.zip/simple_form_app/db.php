<?php
$conn = new mysqli("localhost", "root", "", "book_market");
if ($conn->connect_error) { die("DB Error: " . $conn->connect_error); }
?>
