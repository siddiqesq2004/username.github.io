<?php
require "db.php";

// INSERT / UPDATE
if (isset($_POST["save"])) {
    $id = $_POST["id"] ?? '';
    $name = $_POST["seller_name"];
    $skills = implode(",", $_POST["skills"]);
    $exp = $_POST["experience"];
    $price = $_POST["price_range"];

    // image upload
    if (!empty($_FILES["image"]["name"])) {
        $imgName = time() . "_" . $_FILES["image"]["name"];
        move_uploaded_file($_FILES["image"]["tmp_name"], "uploads/" . $imgName);
    } else {
        $imgName = $_POST["old_image"] ?? "";
    }

    if ($id == "") {
        $conn->query("INSERT INTO experts(name, skills, experience, price, image)
                      VALUES('$name','$skills','$exp','$price','$imgName')");
    } else {
        $conn->query("UPDATE experts SET 
                      name='$name', skills='$skills', experience='$exp',
                      price='$price', image='$imgName' WHERE id=$id");
    }
    header("Location: index.php?done=1");
    exit;
}

// DELETE
if (isset($_GET["delete"])) {
    $conn->query("DELETE FROM experts WHERE id=" . $_GET["delete"]);
    header("Location: index.php?deleted=1");
    exit;
}

// EDIT LOAD
$editData = null;
if (isset($_GET["edit"])) {
    $res = $conn->query("SELECT * FROM experts WHERE id=" . $_GET["edit"]);
    $editData = $res->fetch_assoc();
}
?>
<html>
<head>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">

<h2 class="title">Seller Details</h2>

<form method="POST" enctype="multipart/form-data" class="form-card">

    <input type="hidden" name="id" value="<?= $editData['id'] ?? '' ?>">
    <input type="hidden" name="old_image" value="<?= $editData['image'] ?? '' ?>">

    <label>Seller Name</label>
    <input type="text" name="seller_name" required value="<?= $editData['name'] ?? '' ?>">

    <label>Skills</label>
    <div class="chip-box" id="skillBox"></div>
    <div class="suggestions">
        <?php
        $recommended = ["Editing","Proofreading","Ghostwriting","Cover Design","Formatting","KDP Publishing","Marketing"];
        foreach ($recommended as $r) {
            echo "<span class='chip suggestion' onclick='addSkill(\"$r\")'>$r</span>";
        }
        ?>
    </div>
    <input type="hidden" name="skills[]" id="skillsField">

    <label>Experience</label>
    <select name="experience" required>
        <?php for($i=1;$i<=10;$i++) echo "<option ".(($editData['experience']??'')==$i?'selected':'').">$i</option>"; ?>
        <option <?= (($editData['experience']??'')=="10+")?'selected':'' ?>>10+</option>
    </select>

    <label>Price Range</label>
    <div class="suggestions">
        <?php
        $prices=["300-500","500-1000","1000+"];
        foreach($prices as $p){
            echo "<span class='chip suggestion priceChip' onclick='choosePrice(\"$p\")'>$p</span>";
        }
        ?>
    </div>
    <input type="text" name="price_range" id="priceField" required readonly value="<?= $editData['price'] ?? '' ?>">

    <label>Upload Image</label>
    <input type="file" name="image">

    <button name="save" class="btn"><?= $editData ? "Update" : "Submit" ?></button>
</form>


<?php if (isset($_GET["done"]) || isset($_GET["deleted"])): ?>
<h2 class="title">Saved Sellers</h2>
<table>
<tr>
<th>ID</th><th>Name</th><th>Skills</th><th>Experience</th><th>Price</th><th>Image</th><th>Actions</th>
</tr>
<?php
$rows = $conn->query("SELECT * FROM experts ORDER BY id DESC");
while($r = $rows->fetch_assoc()){
echo "<tr>
<td>{$r['id']}</td>
<td>{$r['name']}</td>
<td>{$r['skills']}</td>
<td>{$r['experience']}</td>
<td>{$r['price']}</td>
<td><img src='uploads/{$r['image']}' class='thumb'></td>
<td>
<a class='edit' href='?edit={$r['id']}'>Edit</a> |
<a class='delete' href='?delete={$r['id']}'>Delete</a>
</td>
</tr>";
}
?>
</table>
<?php endif; ?>

</div>

<script>
let skillList = <?= $editData ? json_encode(explode(",", $editData["skills"])) : "[]" ?>;

function renderSkills(){
    let box = document.getElementById("skillBox");
    box.innerHTML = "";
    skillList.forEach((s,i)=>{
        box.innerHTML += `<span class='chip selected'>${s} <b onclick='removeSkill(${i})'>×</b></span>`;
    });
    document.getElementById("skillsField").value = skillList.join(",");
}

function addSkill(s){
    if(!skillList.includes(s)){
        skillList.push(s);
        renderSkills();
    }
}

function removeSkill(i){
    skillList.splice(i,1);
    renderSkills();
}

renderSkills();

function choosePrice(p){
    document.getElementById("priceField").value = p;
}
</script>

</body>
</html>
