<?php
$conn = new mysqli("localhost", "root", "", "proconnect_db");

// Filters
$skill = $_GET['skill'] ?? '';
$price = $_GET['price'] ?? '';
$exp   = $_GET['exp'] ?? '';

$query = "SELECT * FROM professionals WHERE 1=1";

if ($skill) $query .= " AND skills LIKE '%$skill%'";
if ($price) $query .= " AND price <= $price";
if ($exp) $query .= " AND experience >= $exp";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Professional Marketplace</title>
    <link rel="stylesheet" href="../assets/css/marketplace.css">
</head>
<body>

<!-- SEARCH BAR -->
<div class="search-container">
    <form method="GET" style="display:flex; gap:10px;">
        <input type="text" name="skill" placeholder="Search skills" value="<?php echo $skill; ?>">

        <select name="price">
            <option value="">Max Price</option>
            <option value="20" <?php if ($price=="20") echo "selected"; ?>>$20</option>
            <option value="50" <?php if ($price=="50") echo "selected"; ?>>$50</option>
            <option value="100" <?php if ($price=="100") echo "selected"; ?>>$100</option>
        </select>

        <select name="exp">
            <option value="">Experience</option>
            <option value="1" <?php if ($exp=="1") echo "selected"; ?>>1+ year</option>
            <option value="3" <?php if ($exp=="3") echo "selected"; ?>>3+ years</option>
            <option value="5" <?php if ($exp=="5") echo "selected"; ?>>5+ years</option>
        </select>

        <button type="submit">Search</button>
    </form>
</div>

<!-- RESULTS GRID -->
<div class="card-grid">
    <?php 
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            include "../components/professional-card.php";
        }
    } else {
        echo "<p style='margin-left: 20px; font-size: 18px;'>No professionals found.</p>";
    }
    ?>
</div>

</body>
</html>
