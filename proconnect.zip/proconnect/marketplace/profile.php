<?php
// Connect to database
$conn = new mysqli("localhost", "root", "", "proconnect_db");

// Get ID from URL
$id = $_GET['id'];

// Fetch professional details
$result = $conn->query("SELECT * FROM professionals WHERE id=$id");
$pro = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Professional Profile</title>
</head>
<body>

<h1><?php echo $pro['name']; ?></h1>

<img src="../assets/images/<?php echo $pro['image']; ?>" width="200">

<p><b>Skills:</b> <?php echo $pro['skills']; ?></p>

<p><b>Experience:</b> <?php echo $pro['experience']; ?> years</p>

<p><b>Price:</b> $<?php echo $pro['price']; ?>/hr</p>

<p><?php echo $pro['description']; ?></p>

</body>
</html>
