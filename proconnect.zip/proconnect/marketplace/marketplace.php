<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "proconnect");

$skill_filter = $_GET['skill'] ?? '';
$price_filter = $_GET['price'] ?? '';
$exp_filter = $_GET['experience'] ?? '';

$query = "SELECT * FROM professionals WHERE 1=1";

if ($skill_filter != '') {
    $query .= " AND skills LIKE '%$skill_filter%'";
}
if ($price_filter != '') {
    $query .= " AND price <= $price_filter";
}
if ($exp_filter != '') {
    if ($exp_filter == "10+") {
        $query .= " AND experience >= 10";
    } else {
        $query .= " AND experience = $exp_filter";
    }
}

$result = $conn->query($query);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Marketplace</title>

    <!-- BOOTSTRAP CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

    <!-- CUSTOM STYLE -->
    <style>
        body {
            background: #f4f6f9;
            font-family: Arial, sans-serif;
        }

        .filter-box {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        .card {
            border-radius: 15px;
            overflow: hidden;
            transition: 0.3s;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.15);
        }

        .pro-img {
            height: 180px;
            object-fit: cover;
        }

        .salary {
            font-size: 18px;
            font-weight: bold;
            color: #1e7e34;
        }

        .skill-badge {
            background: #007bff;
            padding: 5px 10px;
            color: white;
            border-radius: 20px;
            margin-right: 5px;
            font-size: 12px;
        }
    </style>
</head>
<body>

<div class="container mt-4">

    <h2 class="mb-4 text-center fw-bold">📚 Professional Marketplace</h2>

    <!-- FILTER SECTION -->
    <div class="filter-box mb-4">
        <form method="GET">
            <div class="row g-3">

                <!-- SKILL FILTER -->
                <div class="col-md-4">
                    <label class="form-label fw-bold">Skill</label>
                    <select name="skill" class="form-select">
                        <option value="">All Skills</option>
                        <option value="Editing">Editing</option>
                        <option value="Proofreading">Proofreading</option>
                        <option value="Cover Design">Cover Design</option>
                        <option value="Marketing">Marketing</option>
                        <option value="Ghostwriting">Ghostwriting</option>
                        <option value="Typesetting">Typesetting</option>
                    </select>
                </div>

                <!-- PRICE FILTER -->
                <div class="col-md-4">
                    <label class="form-label fw-bold">Price (₹300 – ₹1000)</label>
                    <select name="price" class="form-select">
                        <option value="">Select Price</option>
                        <option value="300">Up to ₹300</option>
                        <option value="500">Up to ₹500</option>
                        <option value="700">Up to ₹700</option>
                        <option value="1000">Up to ₹1000</option>
                    </select>
                </div>

                <!-- EXPERIENCE FILTER -->
                <div class="col-md-4">
                    <label class="form-label fw-bold">Experience</label>
                    <select name="experience" class="form-select">
                        <option value="">Any</option>
                        <?php
                        for ($i = 1; $i <= 10; $i++) {
                            echo "<option value='$i'>$i Years</option>";
                        }
                        ?>
                        <option value="10+">10+ Years</option>
                    </select>
                </div>

                <!-- SUBMIT -->
                <div class="col-12 text-end mt-3">
                    <button class="btn btn-primary px-4">Search</button>
                </div>

            </div>
        </form>
    </div>

    <!-- RESULTS SECTION -->
    <div class="row">
        <?php while ($row = $result->fetch_assoc()) { ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="<?php echo $row['image']; ?>" class="card-img-top pro-img" alt="Image Missing">
                    <div class="card-body">
                        <h5 class="fw-bold"><?php echo $row['name']; ?></h5>

                        <p class="salary">₹<?php echo $row['price']; ?></p>

                        <div class="mb-2">
                            <?php
                            $skills = explode(",", $row['skills']);
                            foreach ($skills as $skill) {
                                echo "<span class='skill-badge'>" . trim($skill) . "</span>";
                            }
                            ?>
                        </div>

                        <p>Experience: <b><?php echo $row['experience']; ?> years</b></p>
                        <p><?php echo $row['description']; ?></p>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>

</div>

</body>
</html>
