<div class="pro-card">
    <img src="../assets/images/<?php echo $row['image']; ?>" alt="Professional">

    <div class="pro-name"><?php echo $row['name']; ?></div>

    <div class="pro-details">
        <strong>Skills:</strong> <?php echo $row['skills']; ?><br>
        <strong>Experience:</strong> <?php echo $row['experience']; ?> years<br>
        <strong>Price:</strong> $<?php echo $row['price']; ?>/hr
    </div>

    <a class="view-btn" href="profile.php?id=<?php echo $row['id']; ?>">View Profile</a>
</div>
