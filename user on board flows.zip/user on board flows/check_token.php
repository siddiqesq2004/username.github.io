<?php
require 'db.php';
header('Content-Type: text/plain; charset=utf-8');

$email = 'PUT_THE_EMAIL_HERE'; // <- replace with the email you used on the forgot form
$stmt = $mysqli->prepare("SELECT reset_token, reset_expires_at FROM users WHERE email = ?");
$stmt->bind_param('s', $email);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
if (!$row) {
    echo "No user with that email.\n";
} else {
    var_export($row);
}
