<?php
require 'db.php';
header('Content-Type: text/plain');

echo "Connected to DB: " . $mysqli->host_info . "\n";

$email = 'test_' . time() . '@example.com';
$pass = password_hash('abc12345', PASSWORD_DEFAULT);
$role = 'author';

$stmt = $mysqli->prepare("INSERT INTO users (email, password_hash, role) VALUES (?, ?, ?)");
$stmt->bind_param('sss', $email, $pass, $role);

if ($stmt->execute()) {
    echo "Insert OK: $email\n";
    $res = $mysqli->query("SELECT id, email, role, created_at FROM users ORDER BY id DESC LIMIT 5");
    while ($row = $res->fetch_assoc()) {
        echo "{$row['id']} | {$row['email']} | {$row['role']} | {$row['created_at']}\n";
    }
} else {
    echo "Insert failed: " . $mysqli->error;
}
