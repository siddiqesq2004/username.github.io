<?php
// db.php - update only if DB name / user/pass different
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);

$DB_HOST = '127.0.0.1';
$DB_NAME = 'user_onboard';        // <-- database name created above
$DB_USER = 'root';                // default XAMPP user
$DB_PASS = '';                    // default XAMPP password is empty

$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($mysqli->connect_error) {
    // In dev we send JSON so front-end gets clear error
    header('Content-Type: application/json', true, 500);
    echo json_encode(['error' => 'DB connect error: ' . $mysqli->connect_error]);
    exit;
}
$mysqli->set_charset('utf8mb4');
