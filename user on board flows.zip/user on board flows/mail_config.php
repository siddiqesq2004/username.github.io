<?php
// mail_config.php - central PHPMailer config (manual install)
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Require the PHPMailer source files (adjust path if needed)
require __DIR__ . '/PHPMailer-master/src/Exception.php';
require __DIR__ . '/PHPMailer-master/src/PHPMailer.php';
require __DIR__ . '/PHPMailer-master/src/SMTP.php';

// Create a mailer instance you can reuse
function createMailer() {
    $mail = new PHPMailer(true);

    // SMTP configuration
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'sugesh942005@gmail.com';        // <<-- replace
    $mail->Password   = 'xxeo eoer qoqs qdwn';           // <<-- replace with Gmail App Password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    // Optional: increase debug level for troubleshooting
    // $mail->SMTPDebug = 0; // 0 = off, 2 = show detailed debug (use only while debugging)
    return $mail;
}


