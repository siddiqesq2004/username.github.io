<?php
require 'mail_config.php';
try {
    $mail = createMailer();
    $mail->setFrom('YOUR_EMAIL@gmail.com','Test Mail');
    $mail->addAddress('YOUR_RECEIVING_EMAIL@gmail.com'); // put the address you will check
    $mail->Subject = 'PHPMailer test';
    $mail->Body = 'This is a test message from PHPMailer on XAMPP.';
    $mail->send();
    echo "Sent OK";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
