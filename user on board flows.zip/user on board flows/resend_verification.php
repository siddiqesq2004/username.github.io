<?php
// resend_verification.php
require 'db.php';
require 'mail_config.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$email = trim($data['email'] ?? '');

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid input']);
    exit;
}

$stmt = $pdo->prepare("SELECT id, is_verified FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user) {
    // don't reveal
    echo json_encode(['message' => 'If the email exists, a verification link has been sent.']);
    exit;
}

if ($user['is_verified']) {
    echo json_encode(['message' => 'Already verified.']);
    exit;
}

// generate a new token
$verification_token = bin2hex(random_bytes(32));
$verification_expires_at = date('Y-m-d H:i:s', time() + 60*60*24);
$stmt = $pdo->prepare("UPDATE users SET verification_token = ?, verification_expires_at = ? WHERE id = ?");
$stmt->execute([$verification_token, $verification_expires_at, $user['id']]);

$verifyUrl = 'http://localhost/onboard_demo/verify.php?token=' . urlencode($verification_token);
$html = "<p>Click to verify: <a href='$verifyUrl'>$verifyUrl</a></p>";
send_email($email, 'Resent verification link', $html);
echo json_encode(['message' => 'Verification email resent.']);
