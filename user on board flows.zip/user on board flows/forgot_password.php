<?php
// forgot_password.php
// Expects: db.php and mail_config.php (createMailer()) in same folder.
// Returns JSON.

require 'db.php';
require 'mail_config.php'; // contains createMailer()
header('Content-Type: application/json; charset=utf-8');

try {
    $raw = file_get_contents('php://input');
    $body = json_decode($raw, true);
    $email = trim($body['email'] ?? $_POST['email'] ?? '');

    if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        http_response_code(400);
        echo json_encode(['error' => 'Please provide a valid email.']);
        exit;
    }

    // Find user
    $stmt = $mysqli->prepare("SELECT id, email FROM users WHERE email = ?");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $res = $stmt->get_result();
    $user = $res->fetch_assoc();
    $stmt->close();

    // Security choice: you can return success even if email not found.
    if (!$user) {
        // It's common to not reveal whether the email exists.
        echo json_encode(['message' => 'If that email exists, a reset link has been sent.']);
        exit;
    }

    // Generate token + expiry
    $token = bin2hex(random_bytes(20));
    $expires_at = date('Y-m-d H:i:s', time() + 3600); // 1 hour

    // Store token
    $up = $mysqli->prepare("UPDATE users SET reset_token = ?, reset_expires_at = ? WHERE id = ?");
    $up->bind_param('ssi', $token, $expires_at, $user['id']);
    if (!$up->execute()) {
        http_response_code(500);
        echo json_encode(['error' => 'Could not save reset token.']);
        exit;
    }
    $up->close();

    // Build absolute reset link (adjust folder name if different)
    $reset_link = 'http://localhost/user_on_board_flows/reset_password.php?token=' . urlencode($token);

    // Send email
    try {
        $mail = createMailer(); // from mail_config.php
        $mail->setFrom('sugesh942005@gmail.com', 'YourPlatform'); // change if needed
        $mail->addAddress($user['email']);
        $mail->isHTML(true);
        $mail->Subject = 'Reset your password';
        $mail->Body = "
            <div style='font-family:Arial,Helvetica,sans-serif;color:#0b1436'>
              <p>We received a request to reset the password for <strong>{$user['email']}</strong>.</p>
              <p><a href='{$reset_link}' style='display:inline-block;padding:10px 16px;background:#1677ff;color:#fff;border-radius:6px;text-decoration:none;'>Reset password</a></p>
              <p style='color:#6b7280;font-size:13px;'>If you didn't request this, ignore this email.</p>
              <p style='font-size:12px;color:#9aa6c0;'>Or use this link: <br/>{$reset_link}</p>
            </div>
        ";
        $mail->AltBody = "Reset link: {$reset_link}";
        $mail->send();

        echo json_encode(['message' => 'Reset link sent to your email.']);
        exit;
    } catch (Exception $e) {
        // On dev, return token+link so you can continue testing
        http_response_code(500);
        echo json_encode([
            'error' => 'Mail send failed: ' . $e->getMessage(),
            'token' => $token,
            'reset_link' => $reset_link
        ]);
        exit;
    }

} catch (Exception $ex) {
    http_response_code(500);
    echo json_encode(['error' => 'Server error: ' . $ex->getMessage()]);
}
