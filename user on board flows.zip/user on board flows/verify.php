<?php
// verify.php
require 'db.php';

$token = $_GET['token'] ?? '';

if (!$token) {
    exit('Invalid verification link.');
}

$stmt = $pdo->prepare("SELECT id, verification_expires_at, is_verified FROM users WHERE verification_token = ?");
$stmt->execute([$token]);
$user = $stmt->fetch();

if (!$user) {
    exit('Invalid or already used token.');
}

if ($user['is_verified']) {
    exit('Email already verified. You can login.');
}

if (new DateTime() > new DateTime($user['verification_expires_at'])) {
    exit('Token expired. Please request a new verification email.');
}

// mark verified
$stmt = $pdo->prepare("UPDATE users SET is_verified = 1, verification_token = NULL, verification_expires_at = NULL WHERE id = ?");
$stmt->execute([$user['id']]);

// After verifying, redirect to login page or show success message
echo 'Email verified! <a href="login.html">Go to login</a>';
