<?php
// reset_password.php
// Place this file in your project root (same folder as db.php).
// It will validate the token, show a form, and update the user's password securely.

// Reference image (for your convenience): /mnt/data/Capture.PNG55.PNG

ini_set('display_errors', 0); // hide errors in production; set to 1 while debugging
// error_reporting(E_ALL);

require_once 'db.php'; // your MySQLi connection (expects $mysqli)

function html_escape($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

// Helper: return user row (by exact token or by hash), or null
function find_user_by_token($mysqli, $token) {
    if (!$token) return null;

    // First try direct match (in case you stored plain token)
    $stmt = $mysqli->prepare("SELECT id, email FROM users WHERE reset_token = ? AND reset_expires_at > NOW() LIMIT 1");
    if ($stmt) {
        $stmt->bind_param('s', $token);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($row = $res->fetch_assoc()) {
            $stmt->close();
            return $row;
        }
        $stmt->close();
    }

    // Next try hashed token (sha256) match (in case you stored hash of token)
    $hash = hash('sha256', $token);
    $stmt = $mysqli->prepare("SELECT id, email FROM users WHERE reset_token = ? AND reset_expires_at > NOW() LIMIT 1");
    if ($stmt) {
        $stmt->bind_param('s', $hash);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($row = $res->fetch_assoc()) {
            $stmt->close();
            return $row;
        }
        $stmt->close();
    }

    return null;
}

// Clear token for a user id
function clear_reset_token($mysqli, $user_id) {
    $stmt = $mysqli->prepare("UPDATE users SET reset_token = NULL, reset_expires_at = NULL WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        $stmt->close();
    }
}

// Update password for user id
function update_password($mysqli, $user_id, $newPassword) {
    $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
    $stmt = $mysqli->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
    if (!$stmt) return false;
    $stmt->bind_param('si', $newHash, $user_id);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

// --- Request handling ---
$method = $_SERVER['REQUEST_METHOD'];
$token = $_GET['token'] ?? ($_POST['token'] ?? '');
$token = trim($token);

// If POST, process password update
$message = '';
$error = '';

if ($method === 'POST') {
    // Expect token and two password fields
    $password = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';
    $token = trim($_POST['token'] ?? '');

    // Basic validation
    if (!$token) {
        $error = "Missing token. Use the link from your email.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters long.";
    } elseif ($password !== $password2) {
        $error = "Passwords do not match.";
    } else {
        // find user by token
        $user = find_user_by_token($mysqli, $token);
        if (!$user) {
            $error = "Invalid or expired token. Please request a new password reset.";
        } else {
            $ok = update_password($mysqli, (int)$user['id'], $password);
            if ($ok) {
                clear_reset_token($mysqli, (int)$user['id']);
                $message = "Password updated successfully. You may now <a href='login.html'>login</a>.";
            } else {
                $error = "Could not update password. Please try again later.";
            }
        }
    }
}

// If GET and token present, verify token exists before showing form (optional)
$showForm = true;
if ($method === 'GET') {
    if (!$token) {
        $error = "Missing reset token. Please use the reset link from your email.";
        $showForm = false;
    } else {
        $user = find_user_by_token($mysqli, $token);
        if (!$user) {
            $error = "Invalid or expired token. Request a new password reset.";
            $showForm = false;
        }
    }
}

// --- Simple page HTML (blue theme) ---
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Reset Password</title>
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <style>
    :root{ --bg:#e9f2ff; --card:#ffffff; --primary:#1677ff; --muted:#6b7280; --danger:#ef4444; --success:#10b981; }
    html,body{height:100%;margin:0;font-family:Inter,Segoe UI,Roboto,Arial,sans-serif;background:linear-gradient(180deg,#e6f4ff,#dff0ff);-webkit-font-smoothing:antialiased}
    .wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
    .card{width:100%;max-width:520px;background:var(--card);border-radius:12px;box-shadow:0 12px 30px rgba(16,24,40,0.08);padding:28px}
    h1{margin:0 0 8px;text-align:center;color:#0b1436}
    p.lead{text-align:center;color:var(--muted);margin:0 0 18px}
    .field{display:flex;flex-direction:column;gap:8px;margin-bottom:12px}
    input[type="password"]{height:44px;padding:10px;border-radius:10px;border:1px solid #e6eef8;font-size:15px}
    button.primary{width:100%;height:44px;border-radius:10px;border:0;background:linear-gradient(180deg,var(--primary),#145dbf);color:white;font-weight:700;cursor:pointer}
    .msg{padding:10px;border-radius:8px;margin:12px 0;text-align:center}
    .msg.error{background:#fff0f0;color:var(--danger);border:1px solid #ffd6d6}
    .msg.success{background:#f0f9f4;color:var(--success);border:1px solid #bfead0}
    .small{font-size:13px;color:var(--muted);text-align:center;margin-top:12px}
    a.link{color:var(--primary);text-decoration:none;font-weight:600}
    .hint{font-size:13px;color:#42526a;text-align:center;margin-top:8px}
  </style>
</head>
<body>
  <div class="wrap">
    <main class="card" role="main" aria-labelledby="title">
      <h1 id="title">Reset Password</h1>
      <p class="lead">Enter a new password for your account.</p>

      <?php if ($error): ?>
        <div class="msg error"><?php echo html_escape($error); ?></div>
      <?php endif; ?>

      <?php if ($message): ?>
        <div class="msg success"><?php echo $message; ?></div>
      <?php endif; ?>

      <?php if ($showForm && !$message): ?>
        <form method="post" action="reset_password.php" autocomplete="off" novalidate>
          <input type="hidden" name="token" value="<?php echo html_escape($token); ?>">
          <div class="field">
            <label for="password" style="font-size:13px;color:#374151">New Password</label>
            <input id="password" name="password" type="password" placeholder="At least 6 characters" required>
          </div>

          <div class="field">
            <label for="password2" style="font-size:13px;color:#374151">Confirm Password</label>
            <input id="password2" name="password2" type="password" placeholder="Repeat the password" required>
          </div>

          <button class="primary" type="submit">Set new password</button>
        </form>

        <div class="hint">Password must be at least 6 characters. After a successful reset you'll be redirected to login.</div>
      <?php else: ?>
        <div class="small">Need help? Return to <a class="link" href="forgot.html">Forgot Password</a> or <a class="link" href="login.html">Login</a>.</div>
      <?php endif; ?>
    </main>
  </div>

<script>
  // simple client-side validation to improve UX
  const form = document.querySelector('form');
  if (form) {
    form.addEventListener('submit', (e) => {
      const p1 = document.getElementById('password').value;
      const p2 = document.getElementById('password2').value;
      if (p1.length < 6) {
        e.preventDefault();
        alert('Password must be at least 6 characters.');
        return;
      }
      if (p1 !== p2) {
        e.preventDefault();
        alert('Passwords do not match.');
        return;
      }
      // let server handle the rest
    });
  }
</script>
</body>
</html>
