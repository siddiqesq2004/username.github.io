<?php
// register.php
require 'db.php';
header('Content-Type: application/json');

$raw = file_get_contents('php://input');
$body = json_decode($raw, true);
$data = $body ?? $_POST;

$email = trim($data['email'] ?? '');
$password = $data['password'] ?? '';
$role = ($data['role'] ?? 'author') === 'professional' ? 'professional' : 'author';

// Basic validation
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid email address.']);
    exit;
}
if (strlen($password) < 6) {
    http_response_code(400);
    echo json_encode(['error' => 'Password must be at least 6 characters.']);
    exit;
}

try {
    // Check existing email
    $stmt = $mysqli->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        http_response_code(409);
        echo json_encode(['error' => 'Email already registered.']);
        exit;
    }
    $stmt->close();

    // Insert
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    $verification_token = bin2hex(random_bytes(16));
    $verification_expires_at = date('Y-m-d H:i:s', time() + 60*60*24); // 24h

    $ins = $mysqli->prepare("INSERT INTO users (email, password_hash, role, verification_token, verification_expires_at) VALUES (?, ?, ?, ?, ?)");
    $ins->bind_param('sssss', $email, $password_hash, $role, $verification_token, $verification_expires_at);

    if ($ins->execute()) {
        echo json_encode(['message' => 'Registered successfully', 'token' => $verification_token]);
        exit;
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Database insert failed: ' . $mysqli->error]);
        exit;
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Server error: ' . $e->getMessage()]);
    exit;
}
